import { useState, useCallback } from 'react';
import { FlowData, FlowStep, StepConnection, StepCondition } from '../types';

export const useFlow = () => {
  const [flowData, setFlowData] = useState<FlowData>({
    steps: [],
    nextStepNumber: 1,
  });

  const addStep = useCallback((step: Omit<FlowStep, 'id' | 'position'>, customId?: string) => {
    const stepId = customId || `step-${flowData.nextStepNumber}`;
    
    const newStep: FlowStep = {
      ...step,
      id: stepId,
      position: { 
        x: 50 + (flowData.steps.length % 3) * 300, 
        y: 50 + Math.floor(flowData.steps.length / 3) * 200 
      },
    };

    setFlowData(prev => ({
      steps: [...prev.steps, newStep],
      nextStepNumber: prev.nextStepNumber + 1,
    }));

    return newStep.id;
  }, [flowData.nextStepNumber, flowData.steps.length]);

  const updateStep = useCallback((stepId: string, updates: Partial<FlowStep>) => {
    setFlowData(prev => ({
      ...prev,
      steps: prev.steps.map(step => 
        step.id === stepId ? { ...step, ...updates } : step
      ),
    }));
  }, []);

  const deleteStep = useCallback((stepId: string) => {
    setFlowData(prev => ({
      ...prev,
      steps: prev.steps.filter(step => step.id !== stepId),
    }));
  }, []);

  const addConnection = useCallback((stepId: string, connection: StepConnection) => {
    setFlowData(prev => ({
      ...prev,
      steps: prev.steps.map(step => 
        step.id === stepId 
          ? { ...step, connections: [...step.connections, connection] }
          : step
      ),
    }));
  }, []);

  const updateConnection = useCallback((stepId: string, connectionId: string, updates: Partial<StepConnection>) => {
    setFlowData(prev => ({
      ...prev,
      steps: prev.steps.map(step => 
        step.id === stepId 
          ? {
              ...step,
              connections: step.connections.map(conn => 
                conn.id === connectionId ? { ...conn, ...updates } : conn
              )
            }
          : step
      ),
    }));
  }, []);

  const getStepById = useCallback((stepId: string) => {
    return flowData.steps.find(step => step.id === stepId);
  }, [flowData.steps]);

  const getNextStep = useCallback((currentStepId: string, choice?: string) => {
    const currentStep = getStepById(currentStepId);
    if (!currentStep) return null;

    if (choice && currentStep.connections.length > 0) {
      const connection = currentStep.connections.find(conn => conn.label === choice);
      if (connection && connection.targetStepId) {
        return getStepById(connection.targetStepId);
      }
    }

    // Default to first connection or next step in sequence
    if (currentStep.connections.length > 0 && currentStep.connections[0].targetStepId) {
      return getStepById(currentStep.connections[0].targetStepId);
    }

    // Find next step in sequence
    const currentIndex = flowData.steps.findIndex(step => step.id === currentStepId);
    if (currentIndex >= 0 && currentIndex < flowData.steps.length - 1) {
      return flowData.steps[currentIndex + 1];
    }

    return null;
  }, [flowData.steps, getStepById]);

  return {
    flowData,
    addStep,
    updateStep,
    deleteStep,
    addConnection,
    updateConnection,
    getStepById,
    getNextStep,
  };
};