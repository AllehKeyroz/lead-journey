import React from 'react';
import { MessageSquare, Diamond, Square, GitBranch, Edit2, Trash2 } from 'lucide-react';
import { FlowStep } from '../types';

interface StepCardProps {
  step: FlowStep;
  onEdit: (step: FlowStep) => void;
  onDelete: (stepId: string) => void;
}

export const StepCard: React.FC<StepCardProps> = ({ step, onEdit, onDelete }) => {
  const getStepIcon = () => {
    switch (step.type) {
      case 'message':
        return <MessageSquare size={20} />;
      case 'decision':
        return <Diamond size={20} />;
      case 'action':
        return <Square size={20} />;
      case 'condition':
        return <GitBranch size={20} />;
      default:
        return <MessageSquare size={20} />;
    }
  };

  const getStepColor = () => {
    switch (step.type) {
      case 'message':
        return 'bg-blue-50 border-blue-200 text-blue-700';
      case 'decision':
        return 'bg-green-50 border-green-200 text-green-700';
      case 'action':
        return 'bg-orange-50 border-orange-200 text-orange-700';
      case 'condition':
        return 'bg-purple-50 border-purple-200 text-purple-700';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-700';
    }
  };

  const getStepTypeLabel = () => {
    switch (step.type) {
      case 'message':
        return 'Mensagem';
      case 'decision':
        return 'Decisão';
      case 'action':
        return 'Ação';
      case 'condition':
        return 'Condição';
      default:
        return 'Desconhecido';
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${getStepColor()}`}>
            {getStepIcon()}
          </div>
          <div>
            <h3 className="font-medium text-gray-900">{step.title}</h3>
            <p className="text-sm text-gray-500">{getStepTypeLabel()}</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onEdit(step)}
            className="p-1 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded transition-colors"
          >
            <Edit2 size={16} />
          </button>
          <button
            onClick={() => onDelete(step.id)}
            className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {step.description && (
        <p className="text-sm text-gray-600 mb-3 bg-gray-50 p-2 rounded-lg">
          {step.description}
        </p>
      )}

      {step.connections.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs font-medium text-gray-500 uppercase tracking-wide">
            Conexões
          </h4>
          {step.connections.map((connection) => (
            <div
              key={connection.id}
              className="flex items-center gap-2 text-sm p-2 bg-gray-50 rounded-lg"
            >
              <div className="w-2 h-2 rounded-full bg-gray-400" />
              <span className="text-gray-700">{connection.label}</span>
              {connection.targetStepId && (
                <span className="text-gray-500">→ {connection.targetStepId}</span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};