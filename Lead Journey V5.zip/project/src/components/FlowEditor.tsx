import React, { useState } from 'react';
import { Plus, Play, Zap, Settings } from 'lucide-react';
import { useFlow } from '../hooks/useFlow';
import { StepListItem } from './StepListItem';
import { StepFormModal } from './StepFormModal';
import { Simulator } from './Simulator';
import { FlowStep } from '../types';

export const FlowEditor: React.FC = () => {
  const {
    flowData,
    addStep,
    updateStep,
    deleteStep,
    updateConnection,
  } = useFlow();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStep, setEditingStep] = useState<FlowStep | null>(null);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);

  const handleAddStep = () => {
    setEditingStep(null);
    setIsModalOpen(true);
  };

  const handleEditStep = (step: FlowStep) => {
    setEditingStep(step);
    setIsModalOpen(true);
  };

  const handleSaveStep = (stepData: Omit<FlowStep, 'id' | 'position'>) => {
    if (editingStep) {
      updateStep(editingStep.id, stepData);
    } else {
      addStep(stepData);
    }
  };

  const handleDeleteStep = (stepId: string) => {
    if (confirm('Tem certeza que deseja excluir este passo?')) {
      deleteStep(stepId);
    }
  };

  const handleEditConnection = (stepId: string, connectionId: string) => {
    const step = flowData.steps.find(s => s.id === stepId);
    if (step) {
      setIsSimulatorOpen(false);
      handleEditStep(step);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-800 via-blue-900 to-indigo-900">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="p-3 bg-white/10 backdrop-blur-sm rounded-2xl">
              <Settings className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">
              Editor de Jornada do Lead
            </h1>
          </div>
          <p className="text-xl text-white/90 max-w-2xl mx-auto leading-relaxed">
            Crie fluxos de conversação profissionais e simule a jornada dos seus leads
          </p>
          
          {flowData.steps.length > 0 && (
            <button
              onClick={() => setIsSimulatorOpen(true)}
              className="mt-6 inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
            >
              <Play size={24} />
              Iniciar Simulação
              <Zap size={20} />
            </button>
          )}
        </div>

        {/* Steps Container */}
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl">
          <div className="flex items-center justify-between p-6 border-b border-gray-200">
            <div className="flex items-center gap-4">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-slate-700 to-blue-700 bg-clip-text text-transparent">
                Passos do Fluxo
              </h2>
              <div className="px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full text-sm font-semibold">
                {flowData.steps.length} / 50
              </div>
            </div>
            <button
              onClick={handleAddStep}
              disabled={flowData.steps.length >= 50}
              className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              <Plus size={20} />
              Adicionar Passo
            </button>
          </div>

          {/* Steps List */}
          <div className="max-h-[600px] overflow-y-auto">
            {flowData.steps.map((step, index) => (
              <StepListItem
                key={step.id}
                step={step}
                index={index}
                onEdit={handleEditStep}
                onDelete={handleDeleteStep}
                onUpdateStep={updateStep}
              />
            ))}

            {flowData.steps.length === 0 && (
              <div className="text-center py-16">
                <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full mb-6 shadow-lg">
                  <Settings className="w-12 h-12 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-700 mb-4">
                  Sua jornada começa aqui!
                </h3>
                <p className="text-gray-500 mb-8 text-lg">
                  Crie seu primeiro passo e construa uma experiência profissional
                </p>
                <button
                  onClick={handleAddStep}
                  className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
                >
                  <Plus size={24} />
                  Criar Primeiro Passo
                </button>
              </div>
            )}
          </div>

          {flowData.steps.length >= 50 && (
            <div className="p-4 bg-gradient-to-r from-amber-100 to-yellow-100 border-t border-amber-300">
              <p className="text-amber-800 font-medium text-center">
                ⚡ Limite máximo de 50 passos atingido! Sua jornada está completa.
              </p>
            </div>
          )}
        </div>

        {/* Modals */}
        <StepFormModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveStep}
          editingStep={editingStep}
          existingSteps={flowData.steps}
        />

        <Simulator
          isOpen={isSimulatorOpen}
          onClose={() => setIsSimulatorOpen(false)}
          steps={flowData.steps}
          onEditConnection={handleEditConnection}
          onAddStep={addStep}
          onUpdateStep={updateStep}
        />
      </div>
    </div>
  );
};