import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Settings, Save } from 'lucide-react';
import { FlowStep, StepConnection } from '../types';

interface StepFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (step: Omit<FlowStep, 'id' | 'position'>, customId?: string) => void;
  editingStep?: FlowStep | null;
  existingSteps: FlowStep[];
}

export const StepFormModal: React.FC<StepFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingStep,
  existingSteps,
}) => {
  const [formData, setFormData] = useState({
    title: '',
    type: 'message' as FlowStep['type'],
    description: '',
    connections: [] as StepConnection[],
  });
  const [customId, setCustomId] = useState('');

  useEffect(() => {
    if (editingStep) {
      setFormData({
        title: editingStep.title,
        type: editingStep.type,
        description: editingStep.description || '',
        connections: editingStep.connections,
      });
      setCustomId(editingStep.id);
    } else {
      setFormData({
        title: '',
        type: 'message',
        description: '',
        connections: [],
      });
      setCustomId('');
    }
  }, [editingStep, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData, customId || undefined);
    onClose();
  };

  const addConnection = () => {
    const newConnection: StepConnection = {
      id: `conn-${Date.now()}`,
      label: formData.type === 'message' ? 'Resposta do lead' : 'Próximo',
      targetStepId: null,
    };
    setFormData(prev => ({
      ...prev,
      connections: [...prev.connections, newConnection],
    }));
  };

  const updateConnection = (connectionId: string, updates: Partial<StepConnection>) => {
    setFormData(prev => ({
      ...prev,
      connections: prev.connections.map(conn =>
        conn.id === connectionId ? { ...conn, ...updates } : conn
      ),
    }));
  };

  const removeConnection = (connectionId: string) => {
    setFormData(prev => ({
      ...prev,
      connections: prev.connections.filter(conn => conn.id !== connectionId),
    }));
  };

  const getTypeColors = (type: string) => {
    switch (type) {
      case 'message':
        return 'from-blue-600 to-cyan-600';
      case 'decision':
        return 'from-emerald-600 to-teal-600';
      case 'action':
        return 'from-orange-600 to-amber-600';
      case 'condition':
        return 'from-indigo-600 to-purple-600';
      default:
        return 'from-gray-600 to-slate-600';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-slate-700 to-blue-700 px-8 py-6 flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-white/20 rounded-xl">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">
              {editingStep ? 'Editar Passo' : 'Criar Novo Passo'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-xl transition-colors text-white"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-3">
                ID do Passo
              </label>
              <input
                type="text"
                value={customId}
                onChange={(e) => setCustomId(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-200 focus:border-blue-400 transition-all duration-200 text-lg"
                placeholder="Ex: step-inicio, passo-1..."
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-3">
                Tipo do Passo
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value as FlowStep['type'] }))}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-200 focus:border-blue-400 transition-all duration-200 text-lg"
              >
                <option value="message">💬 Mensagem</option>
                <option value="decision">🔹 Decisão</option>
                <option value="action">⚡ Ação</option>
                <option value="condition">🔀 Condição</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-3">
              Título do Passo
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-200 focus:border-blue-400 transition-all duration-200 text-lg"
              placeholder="Digite o título do passo"
              required
            />
          </div>

          {formData.type === 'message' && (
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-3">
                Conteúdo da Mensagem
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-4 focus:ring-blue-200 focus:border-blue-400 transition-all duration-200 text-lg"
                placeholder="Digite o texto da mensagem que será exibida"
              />
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-6">
              <label className="block text-sm font-bold text-gray-700">
                Conexões e Destinos
              </label>
              <button
                type="button"
                onClick={addConnection}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold"
              >
                <Plus size={18} />
                Adicionar Conexão
              </button>
            </div>

            <div className="space-y-4">
              {formData.connections.map((connection, index) => (
                <div key={connection.id} className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-2xl border-2 border-gray-200">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`w-8 h-8 bg-gradient-to-r ${getTypeColors(formData.type)} text-white rounded-full flex items-center justify-center font-bold text-sm`}>
                      {index + 1}
                    </div>
                    <h4 className="font-semibold text-gray-800">Conexão {index + 1}</h4>
                    <button
                      type="button"
                      onClick={() => removeConnection(connection.id)}
                      className="ml-auto p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-2">
                        Rótulo da Conexão
                      </label>
                      <input
                        type="text"
                        value={connection.label}
                        onChange={(e) => updateConnection(connection.id, { label: e.target.value })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-300 focus:border-blue-400 transition-all duration-200"
                        placeholder="Ex: Sim, Não, Continuar..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-2">
                        Destino
                      </label>
                      <select
                        value={connection.targetStepId || ''}
                        onChange={(e) => updateConnection(connection.id, { targetStepId: e.target.value || null })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-300 focus:border-blue-400 transition-all duration-200"
                      >
                        <option value="">Próximo passo na sequência</option>
                        {existingSteps.map((step) => (
                          <option key={step.id} value={step.id}>
                            {step.title}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 text-gray-700 bg-gray-200 rounded-xl hover:bg-gray-300 transition-colors font-semibold"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex items-center gap-3 px-8 py-3 bg-gradient-to-r from-slate-700 to-blue-700 text-white rounded-xl hover:from-slate-800 hover:to-blue-800 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold"
            >
              <Save size={20} />
              {editingStep ? 'Salvar Alterações' : 'Criar Passo'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};