import React, { useState, useEffect } from 'react';
import { X, ArrowLeft, Play, Edit2, Plus, CheckCircle, Trophy, Zap } from 'lucide-react';
import { FlowStep, SimulationState } from '../types';
import { StepFormModal } from './StepFormModal';

interface SimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  steps: FlowStep[];
  onEditConnection: (stepId: string, connectionId: string) => void;
  onAddStep: (step: Omit<FlowStep, 'id' | 'position'>, customId?: string) => string;
  onUpdateStep: (stepId: string, updates: Partial<FlowStep>) => void;
}

export const Simulator: React.FC<SimulatorProps> = ({
  isOpen,
  onClose,
  steps,
  onEditConnection,
  onAddStep,
  onUpdateStep,
}) => {
  const [simulation, setSimulation] = useState<SimulationState>({
    currentStepId: null,
    history: [],
    isActive: false,
  });
  const [isStepModalOpen, setIsStepModalOpen] = useState(false);
  const [showEndScreen, setShowEndScreen] = useState(false);

  useEffect(() => {
    if (isOpen && steps.length > 0) {
      setSimulation({
        currentStepId: steps[0].id,
        history: [],
        isActive: true,
      });
      setShowEndScreen(false);
    }
  }, [isOpen, steps]);

  const getCurrentStep = () => {
    if (!simulation.currentStepId) return null;
    return steps.find(step => step.id === simulation.currentStepId);
  };

  const getTargetStep = (targetStepId: string | null) => {
    if (!targetStepId) {
      const currentIndex = steps.findIndex(step => step.id === simulation.currentStepId);
      if (currentIndex >= 0 && currentIndex < steps.length - 1) {
        return steps[currentIndex + 1];
      }
      return null;
    }
    return steps.find(step => step.id === targetStepId);
  };

  const handleChoice = (choice: string, targetStepId: string | null) => {
    const targetStep = getTargetStep(targetStepId);
    if (targetStep) {
      setSimulation(prev => ({
        ...prev,
        currentStepId: targetStep.id,
        history: [...prev.history, prev.currentStepId!],
      }));
    } else {
      // Fim do fluxo
      setShowEndScreen(true);
    }
  };

  const handleBack = () => {
    if (simulation.history.length > 0) {
      const previousStepId = simulation.history[simulation.history.length - 1];
      setSimulation(prev => ({
        ...prev,
        currentStepId: previousStepId,
        history: prev.history.slice(0, -1),
      }));
      setShowEndScreen(false);
    }
  };

  const handleRestart = () => {
    if (steps.length > 0) {
      setSimulation({
        currentStepId: steps[0].id,
        history: [],
        isActive: true,
      });
      setShowEndScreen(false);
    }
  };

  const handleAddNewStep = () => {
    setIsStepModalOpen(true);
  };

  const handleSaveNewStep = (stepData: Omit<FlowStep, 'id' | 'position'>, customId?: string) => {
    const newStepId = onAddStep(stepData, customId);
    setIsStepModalOpen(false);
    
    // Navegar para o novo passo
    setSimulation(prev => ({
      ...prev,
      currentStepId: newStepId,
      history: prev.currentStepId ? [...prev.history, prev.currentStepId] : prev.history,
    }));
  };

  const getStepTypeEmoji = (type: string) => {
    switch (type) {
      case 'message': return '💬';
      case 'decision': return '🔹';
      case 'action': return '⚡';
      case 'condition': return '🔀';
      default: return '📝';
    }
  };

  const getStepTypeColor = (type: string) => {
    switch (type) {
      case 'message': return 'from-blue-600 to-cyan-600';
      case 'decision': return 'from-emerald-600 to-teal-600';
      case 'action': return 'from-orange-600 to-amber-600';
      case 'condition': return 'from-indigo-600 to-purple-600';
      default: return 'from-gray-600 to-slate-600';
    }
  };

  if (!isOpen) return null;

  const currentStep = getCurrentStep();

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-emerald-600 to-teal-600 px-8 py-6 flex items-center justify-between rounded-t-2xl">
          <div className="flex items-center gap-4">
            <div className="p-2 bg-white/20 rounded-xl">
              <Play className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white">
              Simulação da Jornada
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-xl transition-colors text-white"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-8">
          {showEndScreen ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full mb-6 shadow-lg">
                <Trophy className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-gray-800 mb-4">
                🎉 Jornada Finalizada!
              </h3>
              <p className="text-gray-600 mb-8 text-lg">
                Parabéns! Você completou toda a jornada do lead com sucesso.
              </p>
              <div className="flex justify-center gap-4">
                <button
                  onClick={handleRestart}
                  className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
                >
                  <Play size={20} />
                  Reiniciar Simulação
                </button>
                <button
                  onClick={handleAddNewStep}
                  className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
                >
                  <Plus size={20} />
                  Adicionar Próximo Passo
                </button>
              </div>
            </div>
          ) : !currentStep ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-gray-400 to-slate-500 rounded-full mb-6 shadow-lg">
                <CheckCircle className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">
                {steps.length === 0 ? 'Nenhum passo encontrado' : 'Passo não encontrado'}
              </h3>
              {steps.length > 0 && (
                <div>
                  <p className="text-gray-600 mb-6 text-lg">
                    O passo atual não foi encontrado. Vamos reiniciar a simulação.
                  </p>
                  <button
                    onClick={handleRestart}
                    className="flex items-center gap-3 mx-auto px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
                  >
                    <Play size={20} />
                    Reiniciar Simulação
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-8">
              {/* Step Header */}
              <div className="text-center">
                <div className={`inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r ${getStepTypeColor(currentStep.type)} text-white rounded-2xl shadow-lg mb-6`}>
                  <span className="text-2xl">{getStepTypeEmoji(currentStep.type)}</span>
                  <span className="font-bold text-lg">
                    {currentStep.type.charAt(0).toUpperCase() + currentStep.type.slice(1)}
                  </span>
                </div>
                <h3 className="text-3xl font-bold text-gray-800 mb-4">
                  {currentStep.title}
                </h3>
                {currentStep.description && (
                  <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-2xl border-l-4 border-blue-400 mb-6">
                    <p className="text-gray-700 text-lg leading-relaxed">
                      {currentStep.description}
                    </p>
                  </div>
                )}
              </div>

              {/* Choices/Actions */}
              <div className="space-y-4">
                {currentStep.type === 'action' ? (
                  <div className="flex justify-center">
                    <button
                      onClick={() => handleChoice('next', currentStep.connections[0]?.targetStepId || null)}
                      className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-2xl hover:from-orange-700 hover:to-amber-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold text-lg"
                    >
                      <Zap size={24} />
                      Executar Ação
                    </button>
                  </div>
                ) : (
                  currentStep.connections.map((connection, index) => (
                    <div key={connection.id} className="flex items-center gap-4">
                      <button
                        onClick={() => handleChoice(connection.label, connection.targetStepId)}
                        className="flex-1 p-6 text-left bg-gradient-to-r from-white to-gray-50 border-2 border-gray-200 rounded-2xl hover:from-blue-50 hover:to-cyan-50 hover:border-blue-300 transition-all duration-300 shadow-md hover:shadow-lg transform hover:scale-[1.02]"
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 bg-gradient-to-r ${getStepTypeColor(currentStep.type)} text-white rounded-full flex items-center justify-center font-bold`}>
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <span className="text-gray-900 font-semibold text-lg block">
                              {connection.label}
                            </span>
                            {connection.targetStepId && (
                              <span className="text-gray-500 text-sm mt-1 block">
                                → {steps.find(s => s.id === connection.targetStepId)?.title}
                              </span>
                            )}
                          </div>
                        </div>
                      </button>
                      <button
                        onClick={() => onEditConnection(currentStep.id, connection.id)}
                        className="p-3 text-blue-500 hover:text-blue-700 hover:bg-blue-50 rounded-xl transition-colors shadow-md hover:shadow-lg"
                        title="Editar destino"
                      >
                        <Edit2 size={20} />
                      </button>
                    </div>
                  ))
                )}

                {/* Add New Step Button */}
                <div className="flex justify-center pt-4">
                  <button
                    onClick={handleAddNewStep}
                    className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold"
                  >
                    <Plus size={20} />
                    Criar Novo Passo
                  </button>
                </div>
              </div>

              {/* Navigation */}
              <div className="flex justify-between items-center pt-6 border-t border-gray-200">
                <button
                  onClick={handleBack}
                  disabled={simulation.history.length === 0}
                  className="flex items-center gap-3 px-6 py-3 text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
                >
                  <ArrowLeft size={20} />
                  Voltar
                </button>
                
                <div className="text-center">
                  <div className="text-sm text-gray-500 mb-1">Progresso</div>
                  <div className="flex items-center gap-2">
                    <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 transition-all duration-500"
                        style={{ width: `${((simulation.history.length + 1) / Math.max(steps.length, 1)) * 100}%` }}
                      />
                    </div>
                    <span className="text-sm font-semibold text-gray-700">
                      {simulation.history.length + 1}/{steps.length}
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleRestart}
                  className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 font-semibold"
                >
                  <Play size={20} />
                  Reiniciar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Step Creation Modal */}
      <StepFormModal
        isOpen={isStepModalOpen}
        onClose={() => setIsStepModalOpen(false)}
        onSave={handleSaveNewStep}
        existingSteps={steps}
      />
    </div>
  );
};