import React, { useState } from 'react';
import { MessageSquare, Diamond, Square, GitBranch, Edit2, Trash2, ChevronDown, ChevronRight, ArrowRight } from 'lucide-react';
import { FlowStep } from '../types';

interface StepListItemProps {
  step: FlowStep;
  index: number;
  onEdit: (step: FlowStep) => void;
  onDelete: (stepId: string) => void;
  onUpdateStep: (stepId: string, updates: Partial<FlowStep>) => void;
}

export const StepListItem: React.FC<StepListItemProps> = ({ 
  step, 
  index, 
  onEdit, 
  onDelete, 
  onUpdateStep 
}) => {
  const [showConnections, setShowConnections] = useState(false);
  const [isEditingId, setIsEditingId] = useState(false);
  const [tempId, setTempId] = useState(step.id);

  const getStepIcon = () => {
    switch (step.type) {
      case 'message':
        return <MessageSquare size={18} />;
      case 'decision':
        return <Diamond size={18} />;
      case 'action':
        return <Square size={18} />;
      case 'condition':
        return <GitBranch size={18} />;
      default:
        return <MessageSquare size={18} />;
    }
  };

  const getStepColors = () => {
    switch (step.type) {
      case 'message':
        return {
          bg: 'from-blue-600 to-cyan-600',
          text: 'text-blue-700',
          lightBg: 'bg-blue-50'
        };
      case 'decision':
        return {
          bg: 'from-emerald-600 to-teal-600',
          text: 'text-emerald-700',
          lightBg: 'bg-emerald-50'
        };
      case 'action':
        return {
          bg: 'from-orange-600 to-amber-600',
          text: 'text-orange-700',
          lightBg: 'bg-orange-50'
        };
      case 'condition':
        return {
          bg: 'from-indigo-600 to-purple-600',
          text: 'text-indigo-700',
          lightBg: 'bg-indigo-50'
        };
      default:
        return {
          bg: 'from-gray-600 to-slate-600',
          text: 'text-gray-700',
          lightBg: 'bg-gray-50'
        };
    }
  };

  const getStepTypeLabel = () => {
    switch (step.type) {
      case 'message':
        return 'Mensagem';
      case 'decision':
        return 'Decisão';
      case 'action':
        return 'Ação';
      case 'condition':
        return 'Condição';
      default:
        return 'Desconhecido';
    }
  };

  const handleIdSave = () => {
    if (tempId.trim() && tempId !== step.id) {
      onUpdateStep(step.id, { id: tempId.trim() });
    }
    setIsEditingId(false);
  };

  const handleIdCancel = () => {
    setTempId(step.id);
    setIsEditingId(false);
  };

  const colors = getStepColors();

  return (
    <div className="border-b border-gray-100 hover:bg-gray-50 transition-colors duration-200">
      <div className="flex items-center gap-4 p-4">
        {/* Step Number */}
        <div className={`w-8 h-8 bg-gradient-to-r ${colors.bg} text-white rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0`}>
          {index + 1}
        </div>

        {/* Step Icon */}
        <div className={`p-2 ${colors.lightBg} rounded-lg flex-shrink-0`}>
          {getStepIcon()}
        </div>

        {/* Step Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-1">
            <h3 className="font-semibold text-gray-900 truncate">{step.title}</h3>
            <span className={`px-2 py-1 bg-gradient-to-r ${colors.bg} text-white rounded-full text-xs font-medium`}>
              {getStepTypeLabel()}
            </span>
          </div>
          
          {/* Editable ID */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">ID:</span>
            {isEditingId ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={tempId}
                  onChange={(e) => setTempId(e.target.value)}
                  className="text-xs border border-gray-300 rounded px-2 py-1 w-24"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleIdSave();
                    if (e.key === 'Escape') handleIdCancel();
                  }}
                  autoFocus
                />
                <button
                  onClick={handleIdSave}
                  className="text-xs text-green-600 hover:text-green-800"
                >
                  ✓
                </button>
                <button
                  onClick={handleIdCancel}
                  className="text-xs text-red-600 hover:text-red-800"
                >
                  ✕
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditingId(true)}
                className="text-xs text-blue-600 hover:text-blue-800 hover:underline"
              >
                {step.id}
              </button>
            )}
          </div>
        </div>

        {/* Connections Toggle */}
        {step.connections.length > 0 && (
          <button
            onClick={() => setShowConnections(!showConnections)}
            className="flex items-center gap-1 px-3 py-1 text-sm text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
          >
            {showConnections ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            {step.connections.length} conexão{step.connections.length !== 1 ? 'ões' : ''}
          </button>
        )}

        {/* Actions */}
        <div className="flex items-center gap-1 flex-shrink-0">
          <button
            onClick={() => onEdit(step)}
            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Editar passo"
          >
            <Edit2 size={16} />
          </button>
          <button
            onClick={() => onDelete(step.id)}
            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Excluir passo"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {/* Connections Expanded */}
      {showConnections && step.connections.length > 0 && (
        <div className="px-4 pb-4 ml-12">
          <div className="bg-gray-50 rounded-lg p-3 space-y-2">
            <h4 className="text-xs font-semibold text-gray-600 uppercase tracking-wide flex items-center gap-2">
              <ArrowRight size={14} />
              Conexões
            </h4>
            {step.connections.map((connection) => (
              <div
                key={connection.id}
                className="flex items-center gap-3 p-2 bg-white rounded-lg border border-gray-200"
              >
                <div className="w-2 h-2 rounded-full bg-gradient-to-r from-blue-400 to-indigo-500" />
                <div className="flex-1">
                  <span className="text-sm font-medium text-gray-800">{connection.label}</span>
                  {connection.targetStepId && (
                    <div className="text-xs text-gray-500 mt-1">
                      → Destino: {connection.targetStepId}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};