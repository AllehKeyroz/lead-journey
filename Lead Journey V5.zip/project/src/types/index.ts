export interface StepConnection {
  id: string;
  label: string;
  targetStepId: string | null;
}

export interface StepCondition {
  variable: string;
  operator: 'contains' | 'not_contains' | 'equals' | 'not_equals' | 'is_empty' | 'is_not_empty';
  value: string;
  targetStepId: string | null;
}

export interface FlowStep {
  id: string;
  title: string;
  type: 'decision' | 'action' | 'message' | 'condition';
  description?: string;
  connections: StepConnection[];
  conditions?: StepCondition[];
  position: { x: number; y: number };
}

export interface FlowData {
  steps: FlowStep[];
  nextStepNumber: number;
}

export interface SimulationState {
  currentStepId: string | null;
  history: string[];
  isActive: boolean;
}