import React from 'react';
import { FlowEditor } from './components/FlowEditor';

function App() {
  return <FlowEditor />;
}

export default App;